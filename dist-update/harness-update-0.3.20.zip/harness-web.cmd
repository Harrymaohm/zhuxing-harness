@echo off
setlocal
set "HARNESS_ROOT=%~dp0"
set "HARNESS_WEB_UI_DIR=%HARNESS_ROOT%web\dist-ui"
set "HARNESS_ICON_PATH=%HARNESS_ROOT%harness.ico"
"%HARNESS_ROOT%node\node.exe" "%HARNESS_ROOT%bin\web-launcher.mjs"
exit /b %errorlevel%
