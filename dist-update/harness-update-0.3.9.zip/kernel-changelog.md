# 《本次内核变更说明》

- 版本：0.3.9 → 0.3.9
- 生成时间：2026/9/8 14:57:42
- 变更基线：v0.3.8
- 内核模块：bin/kernel.mjs
- 变更函数：25 处

## 一、涉及文件

- packages/agent/package.json
- packages/agent/src/index.ts
- packages/bundle/package.json
- packages/bundle/src/index.ts
- packages/cli/package.json
- packages/cli/src/cli.ts
- packages/cli/src/updater.ts
- packages/config/package.json
- packages/harness/package.json
- packages/kernel/package.json
- packages/knowledge/__tests__/kb.test.ts
- packages/knowledge/package.json
- packages/knowledge/src/store.ts
- packages/llm/package.json
- packages/llm/src/openai.ts
- packages/llm/src/types.ts
- packages/memory/__tests__/enhancer.test.ts
- packages/memory/package.json
- packages/memory/src/enhancer.ts
- packages/memory/src/index.ts
- packages/model-router/package.json
- packages/sandbox/package.json
- packages/sdk/package.json
- packages/session/package.json
- packages/skills/package.json
- packages/specs/package.json
- packages/tools/package.json
- packages/web/dist-ui/assets/index-BuF_V-PS.js
- packages/web/dist-ui/assets/index-FbapMpoq.css
- packages/web/dist-ui/assets/pptx_bg-Bz0qOYE5.wasm
- packages/web/dist-ui/index.html
- packages/web/package.json
- packages/web/src/runtime.ts
- packages/web/src/server.ts
- packages/web/ui/src/App.tsx
- packages/web/ui/src/api.ts
- packages/web/ui/src/style.css
- packages/web/ui/src/types.ts
- scripts/build-dist.mjs
- scripts/build-icon.ps1
- scripts/build-update.mjs
- scripts/bundle-cli.mjs
- scripts/gen-harness-doc.ps1
- scripts/gen-poster.ps1
- scripts/gen-user-manual.cjs
- scripts/test-dashscope.ps1

## 二、变更函数（函数级）

- packages/agent/src/index.ts
  - foldResult()
- packages/bundle/src/index.ts
  - defaultSkillDirs()
  - messageToContextText()
  - baseBundlePlugins()
- packages/cli/src/cli.ts
  - cmdUpdate()
- packages/cli/src/updater.ts
  - applyZipToRoot()
  - applyLocalZip()
  - applyRemoteUpdate()
- packages/knowledge/__tests__/kb.test.ts
  - tmp()
- packages/knowledge/src/store.ts
  - genId()
- packages/memory/__tests__/enhancer.test.ts
  - setup()
- packages/memory/src/enhancer.ts
  - buildMemoryPrompt()
  - buildSessionMemoryPrompt()
- packages/web/src/runtime.ts
  - currentKernelKey()
- packages/web/src/server.ts
  - handleRequest()
  - handleChat()
- packages/web/ui/src/App.tsx
  - summarize()
  - rebuildMessages()
  - App()
  - MessageBubble()
  - TraeAssistant()
- packages/web/ui/src/api.ts
  - moveKnowledgeDoc()
- scripts/build-dist.mjs
  - main()
- scripts/build-update.mjs
  - git()
  - main()

## 三、潜在 Bug 修复

- e516d7b fix: 修正内部 workspace 依赖版本范围为 workspace:^，确保构建拓扑正确
- 2e24f53 ci: 修复 pnpm 版本冲突，移除 workflow 中重复的 version 配置，改用 packageManager 统一版本

---
> 本报告由发布脚本基于 git 变更自动生成，用于留存内核更新的证据链，供用户侧核对。
